#!/usr/bin/ksh
$1 $2 ls -1t $3 > $4 < /dev/null
touch conn.test
exit
