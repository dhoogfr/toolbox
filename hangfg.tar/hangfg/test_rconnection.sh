#!/usr/bin/ksh
$1 $2 touch $3 < /dev/null
touch conn.test
