#!/bin/ksh

sqlplus -S /nolog <<END
connect / as sysdba
set echo off
set feedback off
set arraysize 4
set pagesize 0
set pause off
set linesize 200
set verify off
set head off
whenever sqlerror exit sql.sqlcode
spool hq.tmp
select value from v\$parameter where name ='user_dump_dest';
select value from v\$parameter where name ='background_dump_dest';
spool off
END
