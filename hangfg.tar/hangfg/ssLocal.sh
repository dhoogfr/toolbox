#!/bin/sh
#oradebug -g all dump systemstate 10

sqlplus /nolog <<END
connect / as sysdba
set echo off
set feedback off
set arraysize 4
set pagesize 0
set pause off
set linesize 200
set verify off
set head off
oradebug setmypid
oradebug unlimit
oradebug dump systemstate 258 
END
