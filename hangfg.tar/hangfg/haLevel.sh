#!/bin/sh
#oradebug -g all hanganalyze $1

sqlplus -S /nolog <<END
connect / as sysdba
set echo off
set feedback off
set arraysize 4
set pagesize 0
set pause off
set linesize 200
set verify off
set head off
spool hanganalyze.tmp
oradebug setmypid
oradebug unlimit
oradebug -g all hanganalyze $1
spool off
END



