#!/usr/bin/ksh
./hq.sh
if [ $? = 0 ]; then
#  echo "good status"
  touch conn.test
fi
