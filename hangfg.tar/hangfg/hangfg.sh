#!/usr/bin/ksh
######################################################################
# Copyright (c)  2005 by Oracle Corporation
# hangfg.sh
# This is a stand-alone hang file generation program. This program 
# can be run from any node either in a RAC environment or non RAC
# environment. Please see README for full details.
# The output of this program is hanganalyze traces, systemstate dumps
# and process errorstacks if they are in the wait chain and applicable.
# This program produces a list of trace files generated and also 
# collects the files from all nodes and puts them into one tar file.
# This program also generates a log file named hangfg.log which also 
# contains the list
# of files generated along with other debug information.
# 
######################################################################
######################################################################
# Modifications Section:
######################################################################
##     Date        File            Changes
######################################################################
##  09/30/2005                     Baseline version Beta1.0.0 
##
##  09/19/2006                     Changed systemstate level from 10
##  V1.1.0                         to level 266
##  04/09/2007                     Changed medium impact to also look
##  V1.2.0                         at how many additional processes
##                                 would be dumped by running ha level
##                                 4 and if < 10 then to collect an
##                                 additional ha level 4 trace. This
##                                 impact will mimic the light impact
## 10/25/2012                      changed systemstate dump level
## V1.3.0                          from 266 to 258              
######################################################################

echo ""
echo ""
echo ""
echo ""
echo "Starting Hang File Generator V 1.2.0 on "`date` 
echo "HANGFG - Written by Carl Davis, Center of Expertise, Oracle Corporation"
echo ""

HOSTNAME=`hostname`
PLATFORM=`/bin/uname`
lnodesFound=0
processLevel4=0

######################################################################
# Put heartbeat file hangfg.hb in /tmp for RAC-DDT for auto file
# collection.
######################################################################

pwd > /tmp/hangfg.hb

######################################################################
#Cleanup any old files from previous run
######################################################################

# remove list of hang files
if [ -f hangfiles.out ]; then
  rm hangfiles.out
fi
# remove this programs logfile
if [ -f hangfg.log ]; then
  rm hangfg.log
fi
# remove all program temporary files
rm *.tmp
# Remove conn.test file if it exists 
if [ -f conn.test ]; then
  rm conn.test
fi
# Create an archive directory for tarball
if [ -d hangFileArchive ]; then
        rm -rf hangFileArchive
fi
mkdir hangFileArchive  
# Remove hfiles.tar file if it exists 
if [ -f hfiles.tar ]; then
  rm hfiles.tar
fi
# Remove hfiles.tar.Z file if it exists 
if [ -f hfiles.tar.Z ]; then
  rm hfiles.tar.Z
fi
      
echo "" >> hangfg.log
echo "" >> hangfg.log
echo `date`" Program hangfg.sh started on host "$HOSTNAME" for db instance "$ORACLE_SID >> hangfg.log
echo "" >> hangfg.log

######################################################################
#First verify db connection exists to host node and node can process 
#commands
######################################################################
echo ""
echo "Searching for udump/bdump..."
echo ""
./test_connection.sh &
sleep 10

if [ -f conn.test ]; then

######################################################################
# Good connection on host node exists. 
######################################################################

  echo "Database connection established."
  echo `date`" Database connection established." >> hangfg.log
  echo "" >> hangfg.log

######################################################################
# Determine location for udump and bdump
######################################################################

  udump=`grep "/" hq.tmp | head -1` 
  udumpString=` echo $udump | awk '{ print $1 }' `
  bdump=`grep "/" hq.tmp | tail -1`
  bdumpString=` echo $bdump | awk '{ print $1 }' `

  echo `date`" Directory udump found ="$udump  >> hangfg.log
  echo `date`" Directory bdump found ="$bdump  >> hangfg.log
  echo "" >> hangfg.log  


######################################################################  
# Put file marker in udump before any file generation
######################################################################

  udumpFileMarker=$udumpString/hang.fm
  touch $udumpFileMarker

  echo  `date`" Looking for file markers prior to trace generation..." >> hangfg.log
  echo `date`" Latest file in udump= "$udumpFileMarker >> hangfg.log

######################################################################
# Find file markers in bdump before any file generation
######################################################################

  bdumpFileMarker=$bdumpString/hang.fm
  touch $bdumpFileMarker

  echo `date`" Latest file in bdump= "$bdumpFileMarker >> hangfg.log
  echo "" >> hangfg.log   


######################################################################
# Find file markers on remote nodes prior to trace generation
# but first verify ssh is available. if not skip remote collection.
######################################################################


  echo `date`" Looking for ssh..."  >> hangfg.log

  ssh -V > /dev/null 2>&1
  if [ $? = 0 ]; then

    echo `date`" ssh found." >> hangfg.log
    sshStatus=0
    remoteProtocol="ssh"
  else

    echo `date`" ssh not found." >> hangfg.log
    echo `date`" Looking for remsh..."  >> hangfg.log

    d=`which remsh | grep -n "no " > /dev/null 2>&1`
    test $d

    if [ $? = 1 ]; then
      echo `date`" remsh found." >> hangfg.log
      sshStatus=0
      remoteProtocol="remsh"
    else
      echo `date`" remsh not found." >> hangfg.log
      echo `date`" Aborting all remote node collections." >> hangfg.log
      sshStatus=1 
    fi  


  fi
  
  echo "" >> hangfg.log
  
  if [ $sshStatus = 0 ]; then

######################################################################
# ssh found. Check for list of nodes.
######################################################################

    echo `date`" Looking for lsnodes..."  >> hangfg.log

    lsnodes > /dev/null 2>&1
    if [ $? = 0 ]; then

      lsnodes > lnodes.tmp
      echo `date`" lsnodes found." >> hangfg.log
      echo "" >> hangfg.log
      lnodesFound=1

    else

      echo `date`" lsnodes not found." >> hangfg.log 
      echo `date`" Looking for olsnodes..."  >> hangfg.log

      olsnodes > /dev/null 2>&1

      if [ $? = 0 ]; then

        olsnodes > lnodes.tmp
        echo `date`" olsnodes found." >> hangfg.log
        echo "" >> hangfg.log
        lnodesFound=1 

      else
      
        echo `date`" olsnodes not found." >> hangfg.log
        
      fi

    fi     
    
    if [ $lnodesFound = 1 ]; then   

######################################################################
#   List of nodes found. Iterate through list of nodes.
######################################################################


      cat lnodes.tmp | \

      while read line 

      do

#        echo "catting lnodes.tmp"$line

######################################################################
#   if $line /= HOSTNAME process it as a remote node
######################################################################

        s=`echo $HOSTNAME | grep -n $line`
        test $s

        if [ $? = 1 ]; then

          node=$line
          echo  `date`" Looking for file markers prior to trace generation on "$node >> hangfg.log

#         Remove conn.test file if it exists 

          if [ -f conn.test ]; then

            rm conn.test

          fi

          ./test_rconnection.sh $remoteProtocol $line $udumpFileMarker &
          sleep 10
          if [ -f conn.test ]; then

######################################################################  
# Place file marker on remote nodes in udump before any file generation
######################################################################

            echo "Remote Connection established."
            echo `date`" Remote connection established to place filemarker in udump on "$line >> hangfg.log

          else

            echo "Remote Connection failed."
            echo `date`" Remote connection failed while trying to place filemarker in udump on "$line >> hangfg.log
            echo "" >> hangfg.log

          fi  

#         Remove conn.test file if it exists

          if [ -f conn.test ]; then

            rm conn.test

          fi

          ./test_rconnection.sh  $remoteProtocol $line $bdumpFileMarker &
          sleep 10

          if [ -f conn.test ]; then

######################################################################  
# Place file marker on remote nodes in bdump before any file generation
######################################################################

            echo "Remote Connection established."
            echo `date`" Remote connection established to place filemarker in bdump on "$line >> hangfg.log

          else

            echo "Remote Connection failed."
            echo `date`" Remote connection failed while trying to place filemarker in bdump on "$line >> hangfg.log
            echo "" >> hangfg.log

          fi

          echo $node >> rnodes.tmp
        else

          echo $line > localnode.tmp

        fi

      done

    else

      echo ""
      echo "Skipping remote node file collection..."
      echo "Treating collection as single node (non RAC)."
      echo "" >> hangfg.log      
      echo `date`" Skipping remote node file collection." >> hangfg.log
      echo `date`" Treating collection as single node (non RAC)." >> hangfg.log
      echo "" >> hangfg.log

    fi


    echo "" >> hangfg.log
  

  fi

######################################################################  
# Delay 60 seconds to allow file markers to be unique 
######################################################################
  echo ""
  echo "Please wait. File operations in progress..."
  sleep 60
       
######################################################################
# Good connection on host node exists. Process hang trace based on
# input parm level($1) 
# Level 1 = light impact
# Level 2 = medium impact
# Level 3 = heavy impact
######################################################################


  case $1 in
  
######################################################################
# Light Impact
######################################################################

    1)

      echo "Processing Light Impact Hang Trace Collection..."
      echo `date`" Processing Light Impact Hang Trace Collection..." >> hangfg.log
      echo "" >> hangfg.log

      if [ -f hanganalyze.tmp ]; then
        rm hanganalyze.tmp
      fi

      echo "Starting HangAnalyze Trace. Please Wait..."
      echo `date`" Starting hanganalyze Level 3 trace." >> hangfg.log

      if [ $lnodesFound = 1 ]; then 
        ./haLevel.sh 3
      else
        ./haLocalLevel.sh 3
      fi

      echo `date`" Completed hanganalyze Level 3 trace." >> hangfg.log
      echo "Please wait. File operations in progress..."

      sleep 30
      
      if [ -f hanganalyze.tmp ]; then
        rm hanganalyze.tmp
      fi

      echo "Starting HangAnalyze Trace. Please Wait..."
      echo `date`" Starting hanganalyze Level 3 trace." >> hangfg.log

      if [ $lnodesFound = 1 ]; then 
        ./haLevel.sh 3
      else
        ./haLocalLevel.sh 3
      fi

      echo `date`" Completed hanganalyze Level 3 trace." >> hangfg.log
      echo "" >> hangfg.log
      echo "Please wait. File operations in progress..."

      sleep 30

######################################################################
#     Now check to see if it is possible to do a hanganalyze level 4 with
#     little impact. If so, run hanganalyze level 4. If not, skip it
######################################################################
#     tested on cehpclu1 and it did not return ha filename

      echo `date`" Testing for feasability to take HA level 4 trace..." >> hangfg.log
      echo "" >> hangfg.log

######################################################################
#     Look to see if ha returns the ha trace filename
######################################################################

#     grep -i "Analysis in" hanganalyze.tmp > hangline.tmp
#     filename=`awk '{ print $4 }' hangline.tmp`

      filename=`grep -i "Analysis in" hanganalyze.tmp | awk '{ print $4 }' `

      echo "HA Filename="$filename
      echo `date`" HA Filename="$filename >> hangfg.log
     
      test $filename
      if [ $? = 1 ]; then

        echo "Filename not found. Cannot continue with level 4 dump."
        echo `date`" Filename not found. Cannot continue with level 4 dump." >> hangfg.log

      else

######################################################################
#       Look to see if we can find any blockers
######################################################################
#       grep -i "Level  4" "$filename" > level4.tmp
#       blockers=`awk '{ print $4 }' level4.tmp`

        blockers=`grep -i "Level  4" "$filename" | awk '{ print $4 }' `
        echo "blockers="$blockers 
        echo `date`" Blockers="$blockers >> hangfg.log

        test $blockers

        if [ $? = 1 ]; then

          echo "Blocker info missing. Cannot continue with level 4 dump."
          echo `date`" Blocker info missing. Cannot continue with level 4 dump." >> hangfg.log

        else

          if [ $blockers -lt 11 ]; then

            echo "" >> hangfg.log
            echo "Starting HangAnalyze Trace. Please Wait..."
            echo `date`" Starting hanganalyze Level 4 trace." >> hangfg.log

######################################################################
#           All conditions met. Generate HA level 4 trace
######################################################################
  
            if [ $lnodesFound = 1 ]; then 
              ./haLevel.sh 4
            else
              ./haLocalLevel.sh 4
            fi

            echo `date`" Completed hanganalyze Level 4 trace." >> hangfg.log
            echo "" >> hangfg.log

          else

           echo "Too many blockers for hanganalyze level 4 trace." 
           echo `date`" Too many blockers for hanganalyze level 4 trace." >> hangfg.log 
           echo "" >> hangfg.log

          fi  
        fi
      fi             
  ;;
  
######################################################################
# Heavy Impact
######################################################################

    3)

      echo "Processing Heavy Impact Hang Trace Collection..."
      echo `date`" Processing Heavy Impact Hang Trace Collection..." >> hangfg.log
      echo "" >> hangfg.log

      echo "Starting HangAnalyze Trace. Please Wait..."
      echo `date`" Starting hanganalyze Level 4 trace." >> hangfg.log

      if [ $lnodesFound = 1 ]; then 
        ./haLevel.sh 4
      else
        ./haLocalLevel.sh 4
      fi

      echo `date`" Completed hanganalyze Level 4 trace." >> hangfg.log
      echo "Please wait. File operations in progress..."

      sleep 30

      echo "Starting HangAnalyze Trace. Please Wait..."
      echo `date`" Starting hanganalyze Level 4 trace." >> hangfg.log

      if [ $lnodesFound = 1 ]; then 
        ./haLevel.sh 4
      else
        ./haLocalLevel.sh 4
      fi

      echo `date`" Completed hanganalyze Level 4 trace." >> hangfg.log
      echo "Please wait. File operations in progress..."

      sleep 30

      clear
      echo "Starting Systemstate Trace. Please Wait..."
      echo `date`" Starting systemstate level 258 trace." >> hangfg.log

      if [ $lnodesFound = 1 ]; then 
       ./ss.sh
      else
       ./ssLocal.sh
      fi

      echo `date`" Completed systemstate level 258 trace." >> hangfg.log
      echo "Please wait. File operations in progress..."

      sleep 30

      clear
      echo "Starting Systemstate Trace. Please Wait..."
      echo `date`" Starting systemstate level 258 trace." >> hangfg.log

      if [ $lnodesFound = 1 ]; then 
       ./ss.sh
      else
       ./ssLocal.sh
      fi

      echo `date`" Completed systemstate level 258 trace." >> hangfg.log 
      echo "" >> hangfg.log                          

  ;;

######################################################################
# Medium Impact 
######################################################################
 
    *)

      echo "Processing Medium Impact Hang Trace Collection..."
      echo `date`" Processing Medium Impact Hang Trace Collection..." >> hangfg.log
      echo "" >> hangfg.log
      if [ -f hanganalyze.tmp ]; then
        rm hanganalyze.tmp
      fi

      echo "Starting HangAnalyze Trace. Please Wait..."
      echo `date`" Starting hanganalyze Level 3 trace." >> hangfg.log

      if [ $lnodesFound = 1 ]; then 
        ./haLevel.sh 3
      else
        ./haLocalLevel.sh 3
      fi

      echo `date`" Completed hanganalyze Level 3 trace." >> hangfg.log


######################################################################
#     Now check to see if it is possible to do a hanganalyze level 4 with
#     little impact. If so, run hanganalyze level 4. If not, skip it
######################################################################
#     tested on cehpclu1 and it did not return ha filename

      echo `date`" Testing for feasability to take HA level 4 trace..." >> hangfg.log
      echo "" >> hangfg.log

######################################################################
#     Look to see if ha returns the ha trace filename
######################################################################

#     grep -i "Analysis in" hanganalyze.tmp > hangline.tmp
#     filename=`awk '{ print $4 }' hangline.tmp`

      filename=`grep -i "Analysis in" hanganalyze.tmp | awk '{ print $4 }' `

      echo "HA Filename="$filename
      echo `date`" HA Filename="$filename >> hangfg.log
     
      test $filename
      if [ $? = 1 ]; then

        echo "Filename not found. Cannot continue with level 4 dump."
        echo `date`" Filename not found. Cannot continue with level 4 dump." >> hangfg.log
        sleep 30
        if [ -f hanganalyze.tmp ]; then
          rm hanganalyze.tmp
        fi

        echo "Starting HangAnalyze Trace. Please Wait..."
        echo `date`" Starting hanganalyze Level 3 trace." >> hangfg.log

        if [ $lnodesFound = 1 ]; then 
         ./haLevel.sh 3
        else
         ./haLocalLevel.sh 3
        fi

        echo `date`" Completed hanganalyze Level 3 trace." >> hangfg.log
        echo "" >> hangfg.log        

      else

######################################################################
#       Look to see if we can find any blockers
######################################################################
#       grep -i "Level  4" "$filename" > level4.tmp
#       blockers=`awk '{ print $4 }' level4.tmp`

        blockers=`grep -i "Level  4" "$filename" | awk '{ print $4 }' `
        echo "blockers="$blockers 
        echo `date`" Blockers="$blockers >> hangfg.log

        test $blockers

        if [ $? = 1 ]; then

          echo "Blocker info missing. Cannot continue with level 4 dump."
          echo `date`" Blocker info missing. Cannot continue with level 4 dump." >> hangfg.log
          sleep 30
          if [ -f hanganalyze.tmp ]; then
            rm hanganalyze.tmp
          fi

          echo "Starting HangAnalyze Trace. Please Wait..."
          echo `date`" Starting hanganalyze Level 3 trace." >> hangfg.log
  
          if [ $lnodesFound = 1 ]; then 
           ./haLevel.sh 3
          else
           ./haLocalLevel.sh 3
          fi

          echo `date`" Completed hanganalyze Level 3 trace." >> hangfg.log
          echo "" >> hangfg.log  

        else

          if [ $blockers -lt 11 ]; then

            echo "" >> hangfg.log
            echo "Starting HangAnalyze Trace. Please Wait..."
            echo `date`" Starting hanganalyze Level 4 trace." >> hangfg.log

######################################################################
#           All conditions met. Generate HA level 4 trace
######################################################################
            processLevel4=1
            if [ $lnodesFound = 1 ]; then 
              ./haLevel.sh 4
            else

              ./haLocalLevel.sh 4
            fi

            echo `date`" Completed hanganalyze Level 4 trace." >> hangfg.log
            echo "" >> hangfg.log

          else

           echo "Too many blockers for hanganalyze level 4 trace." 
           echo `date`" Too many blockers for hanganalyze level 4 trace." >> hangfg.log 
           echo "" >> hangfg.log
           sleep 30
           if [ -f hanganalyze.tmp ]; then
            rm hanganalyze.tmp
           fi

           echo "Starting HangAnalyze Trace. Please Wait..."
           echo `date`" Starting hanganalyze Level 3 trace." >> hangfg.log
  
           if [ $lnodesFound = 1 ]; then 
            ./haLevel.sh 3
           else
            ./haLocalLevel.sh 3
           fi

           echo `date`" Completed hanganalyze Level 3 trace." >> hangfg.log
           echo "" >> hangfg.log  
           

          fi  
        fi
      fi             


    if [ $processLevel4 = 1 ]; then 
      sleep 30;
      echo "Starting HangAnalyze Trace. Please Wait..."
      echo `date`" Starting hanganalyze Level 4 trace." >> hangfg.log      

      if [ -f hanganalyze.tmp ]; then
        rm hanganalyze.tmp
      fi
      if [ $lnodesFound = 1 ]; then 
        ./haLevel.sh 4

      else
        ./haLocalLevel.sh 4
      fi

      echo `date`" Completed hanganalyze Level 4 trace." >> hangfg.log
      echo "" >> hangfg.log

    fi

    sleep 30

    clear
    echo "Starting Systemstate Trace. Please Wait..."
    echo `date`" Starting systemstate level 258 trace." >> hangfg.log


    if [ $lnodesFound = 1 ]; then 
     ./ss.sh
    else
     ./ssLocal.sh
      fi
      
    echo `date`" Completed systemstate level 258 trace." >> hangfg.log
    echo "" >> hangfg.log  

  ;;
  

  esac  

######################################################################
# File Generation Completed. Prepare list of hang related files.
######################################################################
#

######################################################################
# Find new files created in udump after any file generation
######################################################################

  echo `date`" Searching udump on local node for hang trace files..." >> hangfg.log
  echo "" >> hangfg.log

#  udumpString=` echo $udump | awk '{ print $1 }' `  
  finished=0
  ls -1t $udump | \

  while read line
  do

    if [ $line = "hang.fm" ]; then
      finished=1
    fi

    if [ $finished = 0 ]; then
      if [ -f localnode.tmp ]; then
        localNode=`head -1 localnode.tmp`
      else
        localNode=`hostname`
      fi  

      echo $localNode":"$udumpString"/"$line >> hangfiles.out
      echo $udumpString"/"$line >> localhangfiles.tmp      
      echo `date`" "$udumpString"/"$line >> hangfg.log       

    fi

  done

  echo "" >> hangfg.log

######################################################################
# Find new files created in bdump after any file generation
######################################################################

  echo `date`" Searching bdump on local node for hang trace files..." >> hangfg.log
  echo "" >> hangfg.log

#  bdumpString=` echo $bdump | awk '{ print $1 }' `  
  finished=0
  ls -1t $bdump | \

  while read line
  do

    if [ $line = "hang.fm" ]; then
      finished=1
    fi

    if [ $finished = 0 ]; then
      if [ -f localnode.tmp ]; then
        localNode=`head -1 localnode.tmp`
      else
        localNode=`hostname`
      fi

      echo $localNode":"$bdumpString"/"$line >> hangfiles.out
      echo $bdumpString"/"$line >> localhangfiles.tmp      
      echo `date`" "$bdumpString"/"$line >> hangfg.log       

    fi

  done

  echo "" >> hangfg.log

######################################################################
# Prepare list of remote node hang related files.
######################################################################

  if [ -f rnodes.tmp ]; then

    cat rnodes.tmp | \
    while read line
    do

      node=` echo $line | awk '{ print $1 }' ` 

      echo `date`" Searching udump on "$node" for hang trace files..." >> hangfg.log
   
#     Remove conn.test file if it exists

      if [ -f conn.test ]; then
        rm conn.test
      fi

      ./test_rconnection2.sh  $remoteProtocol $node $udump "rudump.tmp" &
      sleep 10

      if [ -f conn.test ]; then

         echo "Remote Connection established."
         echo `date`" Remote connection established to "$node >> hangfg.log
         echo "" >> hangfg.log

######################################################################
# Find new files created in udump after any file generation on remote
# nodes
######################################################################

         finished=0
         cat rudump.tmp | \
         while read line
         do

           if [ $line = "hang.fm" ]; then
             finished=1
           fi
           if [ $finished = 0 ]; then

             echo $node":"$udumpString"/"$line >> hangfiles.out
             echo `date`" "$udumpString"/"$line >> hangfg.log

           fi
         done

       else

         echo "Remote Connection failed."
         echo `date`" Remote connection failed to "$node >> hangfg.log
         echo "" >> hangfg.log

       fi

      echo `date`" Searching bdump on "$node" for hang trace files..." >> hangfg.log

#     Remove conn.test file if it exists

      if [ -f conn.test ]; then
        rm conn.test
      fi

      ./test_rconnection2.sh  $remoteProtocol $node $bdump "rbdump.tmp" &
      sleep 10

      if [ -f conn.test ]; then

         echo "Remote Connection established."
         echo `date`" Remote connection established to "$node >> hangfg.log
         echo "" >> hangfg.log

######################################################################
# Find new files created in bdump after any file generation on remote
# nodes
######################################################################

         finished=0
         cat rbdump.tmp | \

         while read line
         do


           if [ $line = "hang.fm" ]; then
             finished=1
           fi

           if [ $finished = 0 ]; then


             echo $node":"$bdumpString"/"$line >> hangfiles.out
             echo `date`" "$bdumpString"/"$line >> hangfg.log

           fi
         done

       else

         echo "Remote Connection failed."
         echo `date`" Remote connection failed to "$node >> hangfg.log
         echo "" >> hangfg.log

       fi

  done

# fi rnodes exists
  fi

######################################################################
# Copy files to staging directory hangFileArchive
# 
######################################################################
######################################################################
# Process local files first
######################################################################

  echo ""
  echo "Copying files to hangFileArchive..."
  echo ""

  echo "" >> hangfg.log
  echo `date`" Copying files to hangFileArchive..." >> hangfg.log
  echo "" >> hangfg.log

  if [ -f hangfiles.out ]; then

    cp hangfiles.out hangFileArchive/.

  fi  

  if [ -f localhangfiles.tmp ]; then

    cat localhangfiles.tmp | \

    while read line
    do

      cp $line hangFileArchive/.
      echo `date`"  Copying "$HOSTNAME":"$line" to hangFileArchive" >> hangfg.log

    done  

  fi

######################################################################
# First look to see if remote files exist. If so get a remote copy 
# utilities. If not found then skip remote file transfer for tarball
######################################################################

  if [ -f rnodes.tmp ]; then
    echo `date`" Looking for scp..."  >> hangfg.log

    d=`which scp`

    if [ -x $d ]; then

       echo `date`" scp found." >> hangfg.log
       scpStatus=0
       copyProtocol="scp"
     
    else

       echo `date`" scp not found..."  >> hangfg.log        
       echo `date`" Looking for rcp..."  >> hangfg.log

       d=`which rcp`

       if [ -x $d ]; then

         echo `date`" rcp found." >> hangfg.log
         scpStatus=0
         copyProtocol="rcp"

       else

          echo `date`" rcp not found." >> hangfg.log
          echo `date`" Aborting all remote file collections." >> hangfg.log
          scpStatus=1

       fi   
    fi  


    if [ $scpStatus = 0 ]; then

      cat hangfiles.out | \

      while read line
      do

        s=`echo $line | grep -n $HOSTNAME`
        test $s

        if [ $? = 1 ]; then
        
          $copyProtocol $line hangFileArchive/.
          echo `date`" Copying "$line" to hangFileArchive" >> hangfg.log

        fi 

      done

    fi

  fi

######################################################################
# Tarball hang traces
######################################################################

  echo ""
  echo "Creating tarball of all hangfiles..."
  echo ""

  echo "" >> hangfg.log
  echo `date`" Creating tarball of all hangfiles..." >> hangfg.log
  echo "" >> hangfg.log
  
  tar cvf hfiles.tar hangFileArchive
  compress hfiles.tar

# else initial connection hung 
else

  echo "Failure to connect or connection hanging."
  echo "Aborting hang file generation on host node."
  echo "Please try and run this program on a different node in the cluster."
  echo ""

  echo "Database connection failed or hung. "`date` >> hangfg.log
  echo "" >> hangfg.log
  echo "Aborting hang file generation on host node. "`date` >> hangfg.log 

fi

echo ""
echo "Program hangfg terminated successfully."
echo "More information contained in hangfg.log"

echo "" >> hangfg.log
echo `date`" Program hangfg terminated successfully..." >> hangfg.log

